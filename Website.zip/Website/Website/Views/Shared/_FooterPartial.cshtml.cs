using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Website.Views.Shared
{
    public class _FooterPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

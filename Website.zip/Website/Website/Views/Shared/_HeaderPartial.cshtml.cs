using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Website.Views.Shared
{
    public class _HeaderPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

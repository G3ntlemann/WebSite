using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Website.Views.Shared
{
    public class _MetaPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Website.Views.Shared
{
    public class ScriptsPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

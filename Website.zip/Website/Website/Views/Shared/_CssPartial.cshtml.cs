using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Website.Views.Shared
{
    public class _CssPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

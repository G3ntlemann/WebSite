using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Website.Views.Restaurants
{
    public class SearchModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

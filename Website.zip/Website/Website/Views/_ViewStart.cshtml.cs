using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Website.Views
{
    public class _ViewStartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

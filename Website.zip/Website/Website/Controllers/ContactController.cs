﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Mail;
using System.Threading.Tasks;

namespace Website.Controllers
{
    public class ContactController : Controller
    {
        [HttpPost]

        private async Task SendEmailAsync(ContactFormModel model)
        {
            var mailMessage = new MailMessage
            {
                From = new MailAddress("test_restaurant@outlook.com"), // Почта отправителя
                Subject = "New Contact Form Submission",
                Body = $"Name: {model.Name}\nEmail: {model.Email}\nMessage: {model.Message}"
            };

            mailMessage.To.Add("official_websited@outlook.com"); // Почта получателя

            using (var smtpClient = new SmtpClient("smtp-mail.outlook.com")) // SMTP сервер Outlook
            {
                smtpClient.Credentials = new System.Net.NetworkCredential("test_restaurant@outlook.com", "@123#123"); // Почта отправителя и пароль
                smtpClient.Port = 587; // Порт SMTP сервера
                smtpClient.EnableSsl = true; // Использовать SSL/TLS
                await smtpClient.SendMailAsync(mailMessage);
            }
        }
    }

    public class ContactFormModel
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Message { get; set; }
    }
}
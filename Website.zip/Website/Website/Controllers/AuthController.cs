﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Website.Data;
using Website.Models;
using Website.Services;

namespace Website.Controllers
{
    public class AuthController : Controller
    {
        private readonly AppDbContext _context;

        public AuthController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Register()
        {
            ViewData["IsAuthPage"] = true;
            return View();
        }

        [HttpPost]
        public IActionResult Register(string username, string password, string confirmPassword)
        {
            if (password != confirmPassword)
            {
                ModelState.AddModelError("ConfirmPassword", "Пароли не совпадают.");
                return View();
            }

            if (password.Length < 8 || !password.Any(char.IsDigit) || !password.Any(char.IsLetter))
            {
                ModelState.AddModelError("Password", "Пароль должен содержать минимум 8 символов, включая буквы и цифры.");
                return View();
            }

            if (_context.Users.Any(u => u.Username == username))
            {
                ModelState.AddModelError("Username", "Имя пользователя уже занято.");
                return View();
            }

            byte[] saltBytes = PasswordHasher.GenerateSalt();
            string salt = Convert.ToBase64String(saltBytes); 
            string hashedPassword = PasswordHasher.HashPassword(password, saltBytes);

            var user = new User
            {
                Username = username,
                PasswordHash = hashedPassword,
                Salt = salt 
            };

            _context.Users.Add(user);
            _context.SaveChanges();

            return RedirectToAction("Login");
        }

        public IActionResult Login()
        {
            ViewData["IsAuthPage"] = true;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string username, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == username);

            if (user == null)
            {
                ModelState.AddModelError("Username", "Пользователь не найден.");
                return View();
            }

            byte[] salt = Convert.FromBase64String(user.Salt);

            if (!PasswordHasher.VerifyPassword(user.PasswordHash, password, salt))
            {
                ModelState.AddModelError("Password", "Неверный пароль.");
                return View();
            }

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.Username)
            };

            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var authProperties = new AuthenticationProperties();

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity),
                authProperties);

            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }
    }
}